package com.example.catfacts.data.remote

import com.example.catfacts.data.entities.CatList
import kotlinx.coroutines.Deferred
import retrofit2.http.GET
import retrofit2.http.Query

interface CatApi {
    @GET("/facts/random")
    fun getCats(@Query("limit") limit: Int)
            : Deferred<CatList>
}