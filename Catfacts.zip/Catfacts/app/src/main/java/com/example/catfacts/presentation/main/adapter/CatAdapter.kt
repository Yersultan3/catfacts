package com.example.catfacts.presentation.main.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.catfacts.R
import com.example.catfacts.data.entities.CatList
import kotlinx.android.synthetic.main.item_cat.view.*
import java.lang.System.load
import kotlin.properties.Delegates

class CatAdapter(private val onCatClicked: (imageUrl: String) -> Unit) :
    RecyclerView.Adapter<CatAdapter.CatViewHolder>() {

    private var catsList: List<CatList> by Delegates.observable(emptyList()) { _, _, _ ->
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CatViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_cat, parent, false)
        val holder = CatViewHolder(view)
        holder.itemView.itemCatView.setOnClickListener {
            if (holder.adapterPosition != RecyclerView.NO_POSITION) {
                onCatClicked.invoke(catsList[holder.adapterPosition].text)
            }
        }
        return holder
    }

    override fun getItemCount(): Int = catsList.size

    override fun onBindViewHolder(holder: CatViewHolder, position: Int) {
        if (position != RecyclerView.NO_POSITION) {
            val cat: CatList = catsList[position]
            holder.bind(cat)
        }
    }

    fun updateData(newCatsList:CatList) {
        catsList = listOf(newCatsList)
    }

    class CatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(cat: CatList) {
                load(cat.text)
                (itemView.itemCatView)
        }
    }
}