package com.example.catfacts.data.entities

import com.google.gson.annotations.SerializedName

data class CatList(
    @SerializedName("_id")
    val id: String,
    @SerializedName("text")
    val text: String
)