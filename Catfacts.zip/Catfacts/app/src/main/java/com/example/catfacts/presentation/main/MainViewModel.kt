package com.example.catfacts.presentation.main

import androidx.lifecycle.MutableLiveData
import com.example.catfacts.data.entities.CatList
import com.example.catfacts.data.repository.CatRepository
import com.example.catfacts.presentation.base.BaseViewModel
import com.example.catfacts.utils.SingleLiveEvent
import com.example.catfacts.utils.UseCaseResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val catRepository: CatRepository) : BaseViewModel() {

    val showLoading = MutableLiveData<Boolean>()
    val catsList = MutableLiveData<CatList>()
    val showError = SingleLiveEvent<String>()
    val navigateToDetail = SingleLiveEvent<String>()

    init {
        loadCats()
    }

    private fun loadCats() {
        showLoading.value = true
        launch {

            val result = withContext(Dispatchers.IO) { catRepository.getCatsList() }
            showLoading.value = false
            when (result) {
                is UseCaseResult.Success -> catsList.value = result.data
                is UseCaseResult.Error -> showError.value = result.exception.message
            }
        }
    }

    fun catClicked(text: String) {
        navigateToDetail.value = text
    }
}
