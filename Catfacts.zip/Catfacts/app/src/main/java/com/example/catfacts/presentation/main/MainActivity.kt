package com.example.catfacts.presentation.main

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import com.example.catfacts.R
import com.example.catfacts.presentation.main.adapter.CatAdapter
import kotlinx.android.synthetic.main.activity_main.*
import org.koin.android.viewmodel.ext.android.viewModel

const val NUMBER_OF_COLUMN = 3

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModel()
    private lateinit var catAdapter: CatAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val onCatClicked: (imageUrl: String) -> Unit = { imageUrl ->
            viewModel.catClicked(imageUrl)
        }
        catAdapter = CatAdapter(onCatClicked)
        catsRecyclerView.apply {
            layoutManager = GridLayoutManager(
                this@MainActivity,
                NUMBER_OF_COLUMN
            )
            adapter = catAdapter
        }
        initViewModel()
    }

    private fun initViewModel() {
        viewModel.catsList.observe(this, Observer { newCatsList ->
            catAdapter.updateData(newCatsList!!)
        })
        viewModel.showLoading.observe(this, Observer { showLoading ->
            mainProgressBar.visibility = if (showLoading!!) View.VISIBLE else View.GONE
        })
        viewModel.showError.observe(this, Observer { showError ->
            Toast.makeText(this, showError, Toast.LENGTH_SHORT).show()
        })

    }

}
