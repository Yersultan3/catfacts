package com.example.catfacts.data.repository

import com.example.catfacts.data.entities.CatList
import com.example.catfacts.data.remote.CatApi
import com.example.catfacts.utils.UseCaseResult

const val NUMBER_OF_CATS = 5

interface CatRepository {
    suspend fun getCatsList(): UseCaseResult<CatList>
}

class CatRepositoryImpl(private val catApi: CatApi) : CatRepository {
    override suspend fun getCatsList(): UseCaseResult<CatList> {

        return try {
            val result = catApi.getCats(limit = NUMBER_OF_CATS).await()
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }
}